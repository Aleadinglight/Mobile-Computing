package com.example.assignment5_2

import android.os.Bundle
import android.text.Html
import android.text.Spannable
import android.text.method.PasswordTransformationMethod
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.LinearLayout.LayoutParams
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import java.util.*

class MainActivity : AppCompatActivity() {
    private val SPEED = 40
    private var stage = 0

    private val layout by lazy {
        LinearLayout(this)
    }
    private val labelUsername by lazy {
        val label = TextView(this)
        label.text = "Username"
        label.layoutParams = layoutParams
        label
    }
    private val labelPassword by lazy {
        val label = TextView(this)
        label.text = "Password"
        label.layoutParams = layoutParams
        label
    }
    private val inputUsername by lazy {
        val input = EditText(this)
        input.setBackgroundResource(R.drawable.inputborder_normal)
        input.layoutParams = layoutParams
        input.setPadding(10)
        input
    }
    private val inputPassword by lazy {
        val input = EditText(this)
        input.setBackgroundResource(R.drawable.inputborder_normal)
        input.transformationMethod = PasswordTransformationMethod.getInstance();
        input.layoutParams = layoutParams
        input.setPadding(10)
        input
    }
    private val button by lazy {
        val button = Button(this)
        button.text = "Toggle the other"
        button.layoutParams = layoutParams
        button
    }
    private val textSummary by lazy {
        val text = TextView(this)
        text.text = ""
        text.layoutParams = layoutParams
        text
    }

    private val layoutParams by lazy {
        val params = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        params.leftMargin = 16
        params.rightMargin = 16
        params.topMargin = 16
        params.bottomMargin = 16
        params
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // create the layout
        layout.orientation = LinearLayout.VERTICAL

        // Username
        layout.addView(labelUsername)
        layout.addView(inputUsername)

        // Password
        layout.addView(labelPassword)
        layout.addView(inputPassword)

        // Continue button
        button.setOnClickListener {
            transitToStage(stage + 1)
        }
        layout.addView(button)

        // Summary section
        layout.addView(textSummary)

        // init stage = 0
        transitToStage(0)


        this.addContentView(layout, layoutParams)
    }

    private fun transitToStage(newStage: Int) {
        when (newStage) {
            0 -> {
                // Initial stage. Only username field in the beginning.)

                // input borders
                inputUsername.setBackgroundResource(R.drawable.inputborder_normal)
                inputUsername.setBackgroundResource(R.drawable.inputborder_normal)

                // state
                stage = 0
                usernameIs(View.VISIBLE, "")
                passwordIs(View.INVISIBLE, "")
                button.text = "Continue"
                textSummary.text = ""
            }
            1 -> {
                // After typing the username and pressing Continue button, the application should then show a text field for password.

                // input borders
                if (inputUsername.text.isEmpty()) {
                    inputUsername.setBackgroundResource(R.drawable.inputborder_invalid)
                    return
                } else {
                    inputUsername.setBackgroundResource(R.drawable.inputborder_normal)
                }
                inputUsername.setBackgroundResource(R.drawable.inputborder_normal)

                // state
                stage = 1
                usernameIs(View.VISIBLE, null)
                passwordIs(View.VISIBLE, "")
                button.text = "Continue"
                textSummary.setText("")
            }
            2 -> {
                // After filling the password field and pressing Continue button, the application should then display user info and the current data and time.

                // input borders
                if (inputUsername.text.isEmpty()) {
                    inputUsername.setBackgroundResource(R.drawable.inputborder_invalid)
                    return
                } else {
                    inputUsername.setBackgroundResource(R.drawable.inputborder_normal)
                }
                if (inputPassword.text.isEmpty()) {
                    inputPassword.setBackgroundResource(R.drawable.inputborder_invalid)
                    return
                } else {
                    inputPassword.setBackgroundResource(R.drawable.inputborder_normal)
                }

                // proceed
                stage = 2
                usernameIs(View.VISIBLE, null)
                passwordIs(View.VISIBLE, null)
                button.text = "Back"
                textSummary.setText(Html.fromHtml(renderSummary()))
            }
            else -> {
                transitToStage(0)
            }
        }
    }

    private fun now(): String {
        return Calendar.getInstance().time.toString()
    }

    private fun usernameIs(visibility: Int, value: String?) {
        labelUsername.visibility = visibility
        inputUsername.visibility = visibility
        if (value != null) {
            inputUsername.setText(value)
        }
    }

    private fun passwordIs(visibility: Int, value: String?) {
        labelPassword.visibility = visibility
        inputPassword.visibility = visibility
        if (value != null) {
            inputPassword.setText(value)
        }
    }

    private fun renderSummary(): String {
        var summary = ""
        summary += "<b>Date:</b> " + now() + "<br/>"
        summary += "<b>Username:</b> " + inputUsername.text + "<br/>"
        summary += "<b>Password:</b> " + inputPassword.text + "<br/>"
        return summary
    }
}